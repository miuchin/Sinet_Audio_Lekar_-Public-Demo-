# Code of Conduct

We want this project to be helpful, respectful, and welcoming.

## Expected behavior
- Be respectful and constructive
- Focus on the issue, not the person
- Help improve clarity for end users (especially non-technical users)

## Unacceptable behavior
- Harassment or insults
- Discriminatory language
- Intentional sabotage or misleading changes

## Enforcement
Maintainers may edit/remove comments or close discussions that violate these guidelines.
