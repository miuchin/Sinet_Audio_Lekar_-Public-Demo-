## Summary
- 

## Why
- 

## What changed
- 

## Tested on
- [ ] Desktop browser
- [ ] Android browser / WebView
- [ ] iPhone Safari / PWA
- [ ] `index-nosw.html` (if relevant)

## Screenshots (if UI change)
- 
