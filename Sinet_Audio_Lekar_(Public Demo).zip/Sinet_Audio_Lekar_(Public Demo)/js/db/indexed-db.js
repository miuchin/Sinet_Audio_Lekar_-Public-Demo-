/*
  SINET Audio Lekar — IndexedDB Layer
  File: js/db/indexed-db.js
  Version: 1.2
  Author: miuchins | Co-author: SINET AI
  Notes:
    - Favorites, main playlist, last session resume, audit log (append-only)
*/

const DB_CONFIG = {
  name: "SINET_Audio_DB",
  version: 4,
};

class SinetDB {
  constructor() {
    this.db = null;
    this.isReady = false;
  }

  async init() {
    if (this.isReady && this.db) return true;

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_CONFIG.name, DB_CONFIG.version);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains("state")) {
          db.createObjectStore("state", { keyPath: "key" });
        }
        if (!db.objectStoreNames.contains("favorites")) {
          db.createObjectStore("favorites", { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains("playlists")) {
          db.createObjectStore("playlists", { keyPath: "id", autoIncrement: true });
        }
        if (!db.objectStoreNames.contains("protocols")) {
          db.createObjectStore("protocols", { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains("audit_log")) {
          db.createObjectStore("audit_log", { keyPath: "id", autoIncrement: true });
        }
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        this.isReady = true;
        console.log("SINET DB: Ready");
        resolve(true);
      };

      request.onerror = () => {
        console.error("SINET DB: Init error", request.error);
        reject(request.error);
      };
    });
  }

  async _ensure() {
    if (!this.db || !this.isReady) await this.init();
  }

  _tx(storeName, mode) {
    if (!this.db) throw new Error("DB not initialized");
    return this.db.transaction(storeName, mode).objectStore(storeName);
  }

  _put(storeName, item) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, "readwrite");
      const req = store.put(item);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  _getRaw(storeName, key) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, "readonly");
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  _get(storeName, key) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, "readonly");
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? (req.result.data ?? req.result) : null);
      req.onerror = () => reject(req.error);
    });
  }

  _getAll(storeName) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, "readonly");
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  _delete(storeName, key) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, "readwrite");
      const req = store.delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  /* ---------- Audit (append-only) ---------- */
  async logAction(category, action, details = "") {
    try {
      await this._ensure();
      await this._put("audit_log", {
        timestamp: new Date().toISOString(),
        category, action, details,
        userAgent: navigator.userAgent
      });
    } catch(e) {}
  }

  async getAuditLog(limit = 500) {
    await this._ensure();
    const all = await this._getAll("audit_log");
    return all.slice(Math.max(0, all.length - limit));
  }

  /* ---------- Favorites ---------- */
  async toggleFavorite(simptomId) {
    await this._ensure();
    const exists = await this._getRaw("favorites", simptomId);
    if (exists) {
      await this._delete("favorites", simptomId);
      this.logAction("USER", "Removed Favorite", simptomId);
      return false;
    }
    await this._put("favorites", { id: simptomId, addedAt: Date.now() });
    this.logAction("USER", "Added Favorite", simptomId);
    return true;
  }

  async getFavorites() {
    await this._ensure();
    return this._getAll("favorites");
  }

  /* ---------- Main playlist ---------- */
  async saveMainPlaylist(items) {
    await this._ensure();
    return this._put("state", { key: "main_playlist", data: Array.isArray(items) ? items : [], updatedAt: Date.now() });
  }

  async getMainPlaylist() {
    await this._ensure();
    const v = await this._get("state", "main_playlist");
    return Array.isArray(v) ? v : [];
  }

  async clearMainPlaylist() {
    await this._ensure();
    return this._delete("state", "main_playlist");
  }

  /* ---------- Resume state ---------- */
  async savePlayerState(stateData) {
    await this._ensure();
    return this._put("state", { key: "last_session", data: stateData || null, updatedAt: Date.now() });
  }

  async getPlayerState() {
    await this._ensure();
    return this._get("state", "last_session");
  }

  async clearPlayerState() {
    await this._ensure();
    return this._delete("state", "last_session");
  }


  /* ---------- Protocols (user-defined sequences) ---------- */
  async getProtocols() {
    await this._ensure();
    const rows = await this._getAll("protocols");
    // newest first
    return (Array.isArray(rows) ? rows : []).sort((a,b)=> (Number(b.updatedAt||b.createdAt||0) - Number(a.updatedAt||a.createdAt||0)));
  }

  async getProtocol(id) {
    await this._ensure();
    if (!id) return null;
    const raw = await this._getRaw("protocols", id);
    return raw || null;
  }

  async putProtocol(proto) {
    await this._ensure();
    if (!proto || typeof proto !== "object") throw new Error("Invalid protocol");
    if (!proto.id) throw new Error("Protocol missing id");
    const now = Date.now();
    const row = { ...proto };
    if (!row.createdAt) row.createdAt = now;
    row.updatedAt = now;
    await this._put("protocols", row);
    this.logAction("USER", "Save Protocol", String(row.id));
    return true;
  }

  async deleteProtocol(id) {
    await this._ensure();
    if (!id) return false;
    await this._delete("protocols", id);
    this.logAction("USER", "Delete Protocol", String(id));
    return true;
  }

  /* ---------- Backup / Restore ---------- */
  async exportAll() {
    await this._ensure();
    const state = await this._getAll("state");
    const favorites = await this._getAll("favorites");
    const playlists = await this._getAll("playlists");
    const audit = await this._getAll("audit_log");
    const protocols = await this._getAll("protocols");
    return { exportedAt: new Date().toISOString(), state, favorites, playlists, protocols, audit };
  }

  async importAll(payload) {
    await this._ensure();
    if (!payload || typeof payload !== "object") throw new Error("Invalid backup file");

    // read-only audit philosophy: DO NOT import audit
    const state = Array.isArray(payload.state) ? payload.state : [];
    const favorites = Array.isArray(payload.favorites) ? payload.favorites : [];
    const playlists = Array.isArray(payload.playlists) ? payload.playlists : [];
    const protocols = Array.isArray(payload.protocols) ? payload.protocols : [];

    for (const s of state) {
      if (s && typeof s === "object" && s.key) await this._put("state", s);
    }
    for (const f of favorites) {
      if (f && typeof f === "object" && f.id) await this._put("favorites", f);
    }

    // playlists store uses keyPath "id" (autoIncrement). We import as-is; if ids clash, later import overwrites.
    for (const p of playlists) {
      if (p && typeof p === "object") await this._put("playlists", p);
    }

    // protocols store uses keyPath "id". Import as-is.
    for (const pr of protocols) {
      if (pr && typeof pr === "object" && pr.id) await this._put("protocols", pr);
    }

    this.logAction("USER", "Restore Backup", "Import All");
    return true;
  }
}

window.db = new SinetDB();
console.log("SINET DB: Kreirana globalna instanca window.db");
