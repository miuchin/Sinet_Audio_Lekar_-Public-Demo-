SINET – Akupresura (offline media)

U ovaj folder dodaj slike za tačke (npr. LI4.png) i upiši ih u registry.json.

Pravila:
- Koristi samo slike koje su tvoje ili imaju eksplicitnu licencu za upotrebu.
- U registry.json upiši izvor i licencu (ako postoji).
- Putanja mora biti relativna u odnosu na root projekta.
