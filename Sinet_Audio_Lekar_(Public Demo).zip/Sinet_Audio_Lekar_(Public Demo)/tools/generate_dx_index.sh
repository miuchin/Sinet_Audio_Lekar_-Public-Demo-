#!/usr/bin/env bash
python3 tools/generate_dx_index.py "$@"
