# RELEASE NOTES v15.7.9.6

## New
- Tutor / Vodiči central hub
- Quick Start (3 klika) tutor
- AI Upitnik → Protokol tutor
- Direct Tutor/Vodiči entry from Menu and Settings

## Improvements
- Better discoverability of educational content for end users
- Help/Tutor workflow orientation for non-technical users
