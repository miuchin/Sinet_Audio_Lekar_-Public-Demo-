# RELEASE NOTES v15.7.9.1

- Huawei/older Android mobile scroll + header compact hotfix.
- Main/nav-menu scroll reliability improved (min-height:0 in flex scrollers).
- Mobile header reduced to hamburger + activate to prevent large fixed top area.
- Quickbar no longer sticky on small screens (scrolls away).
- Player controls wrap on narrow screens to prevent clipping.
