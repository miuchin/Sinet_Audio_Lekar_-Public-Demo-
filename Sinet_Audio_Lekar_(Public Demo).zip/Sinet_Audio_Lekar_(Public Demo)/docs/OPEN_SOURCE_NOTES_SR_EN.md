# Open Source Notes (SR / EN)

## SR
Ovaj paket je pripremljen za javnu objavu kao **Public Demo**.
Ako imate internu/full verziju, preporuka je:
- javni repo = demo + dokumentacija + tutor vodiči
- privatni repo = razvojne/interno-specifične funkcije, eksperimenti, privatni dataset-ovi

## EN
This package is prepared for a public **Public Demo** release.
If you maintain a private/full version, a good split is:
- public repo = demo + documentation + tutor guides
- private repo = internal features, experiments, private datasets
